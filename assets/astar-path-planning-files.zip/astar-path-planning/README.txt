A* Path Planning Coursework Files

This archive contains the main source files for the AMR path planning coursework project:
- gui.py: PyQt interface used to set grid size, obstacles, start/end cells and run the planner.
- pathPlanner.py: A* path planning implementation using a Euclidean-distance heuristic.

Generated cache files, editor settings and unrelated notebook material have been excluded from this public portfolio archive.
